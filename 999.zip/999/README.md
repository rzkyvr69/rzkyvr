# 999Dice Premium Script
An Dice mining script for [999DOGE]( https://www.999doge.com/?319436992)

<p align="center">
  <img src="preview.png" alt="preview">
</p>

<p align="center">
  <img src="preview2.png" alt="preview">
</p>

## Get Started

### Ubuntu
```
sudo apt update
```
```
sudo apt upgrade
```
```
sudo apt install python python-pip curl -y
```
```
pip3 install colorama
```
```
pip3 install requests
```
```
pip3 install bs4
```
```
git clone https://github.com/MonkeyD-Core/999
```
```
cd 999
```
```
python3 999dice.py
```
### Termux
```
pkg update
```
```
pkg upgrade
```
```
pkg install git python python-pip curl -y
```
```
pip3 install colorama
```
```
pip3 install requests
```
```
pip3 install bs4
```
```
git clone https://github.com/MonkeyD-Core/999
```
```
cd 999
```
```
python3 999dice.py
```
## Configuration
```
config.json
```
```
     "Username": "xxx",
     "Password": "xxx"
```
```
"Name Bet Set": "Happy Mining ðŸ¤‘",
     "Base Bet": "0.1",
     "Max Bet": "OFF",
     "Chance": "80",
     "Random Chance": {
          "Toggle": "ON",
          "Min": "80",
          "Max": "82"
        },
     "Bet": {
          "Bet": "Hi",
          "Hi / Low": {
              "Toggle": "0",
              "If Lose": "1",
              "If Win": "2"
            }
	        },
     "If Win": "1.01",
     "If Lose": "3.01",
     "Reset If Win": "1",
     "Reset If Profit": "0.000001",
     "Interval": "1"
     },{
```
## Contact
[Telegram]( https://t.me/monkeydc)
[Email]( mailto:imskaa.co@gmail.com)

Donations for continued support of this script are welcomed at:

* BTC 1Fg8YGLWgx9jqVEJdmFpeysefZvgF9wntF
* DOGE D8tYBRk3gqYiFU4xbdPmuzPcNan39ZB53c 
* ETH 0xB5a42d6f61d2f9049D6Cb6E0Db262E686BD752eF
* UBI ubi1qlmwhu9dvax5xp72vhcwr8n2kcjv92zrkt38v3a
* LTC LfnGo77nhE3NtEBy2UGK61c3Te1J9HQavP
